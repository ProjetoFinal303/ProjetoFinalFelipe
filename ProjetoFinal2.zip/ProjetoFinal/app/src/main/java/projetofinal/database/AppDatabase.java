package projetofinal.database;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;
import android.content.Context;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import projetofinal.models.Cliente;
import projetofinal.models.Pedido;
import projetofinal.dao.ClienteDao;
import projetofinal.dao.PedidoDao;

@Database(entities = {Cliente.class, Pedido.class}, version = 2, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {

    public abstract ClienteDao clienteDao();
    public abstract PedidoDao pedidoDao();

    private static volatile AppDatabase INSTANCE;
    private static final int NUM_THREADS = 4;
    static final ExecutorService databaseWriteExecutor = Executors.newFixedThreadPool(NUM_THREADS);

    public static AppDatabase getInstance(final Context context) {
        if (INSTANCE == null) {
            synchronized (AppDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                                    AppDatabase.class, "lanchonete_db")
                            .fallbackToDestructiveMigration() // Apaga banco se mudar estrutura
                            .addCallback(new RoomDatabase.Callback() {
                                @Override
                                public void onCreate(@androidx.annotation.NonNull SupportSQLiteDatabase db) {
                                    super.onCreate(db);
                                    databaseWriteExecutor.execute(() -> {
                                        AppDatabase database = getInstance(context);
                                        ClienteDao clienteDao = database.clienteDao();

                                        // Adicionando cliente inicial de forma segura
                                        Cliente clienteInicial = new Cliente("Cliente Exemplo", "(00) 00000-0000");
                                        if (clienteDao.clienteExiste(1) == 0) { // Evita duplicação
                                            clienteDao.inserir(clienteInicial);
                                        }
                                    });
                                }
                            })
                            .build();
                }
            }
        }
        return INSTANCE;
    }
}
