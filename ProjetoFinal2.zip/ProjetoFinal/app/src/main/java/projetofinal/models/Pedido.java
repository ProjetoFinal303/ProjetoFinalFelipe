package projetofinal.models;

import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;
import androidx.room.Ignore;
import androidx.room.ColumnInfo;

@Entity(tableName = "Pedido",
        foreignKeys = @ForeignKey(entity = Cliente.class,
                parentColumns = "id",
                childColumns = "id_cliente",
                onDelete = ForeignKey.CASCADE))
public class Pedido {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    private int id;

    @ColumnInfo(name = "data")
    private String data;

    @ColumnInfo(name = "status")
    private String status;

    @ColumnInfo(name = "id_cliente")
    private int id_cliente;

    // Construtor vazio necessário para o Room
    public Pedido() {}

    @Ignore
    public Pedido(String data, String status, int id_cliente) {
        this.data = data;
        this.status = status;
        this.id_cliente = id_cliente;
    }

    // Getters e Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getData() { return data; }
    public void setData(String data) { this.data = data; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public int getId_cliente() { return id_cliente; }
    public void setId_cliente(int id_cliente) { this.id_cliente = id_cliente; }
}
