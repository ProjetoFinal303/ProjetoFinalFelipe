package projetofinal.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import projetofinal.models.Pedido;
import java.util.List;

@Dao
public interface PedidoDao {
    @Insert
    long inserir(Pedido pedido); // ✅ Retorna o ID gerado

    @Insert
    long[] inserirTodos(List<Pedido> pedidos); // ✅ Para inserção em massa

    @Delete
    int excluir(Pedido pedido); // ✅ Retorna o número de linhas excluídas

    @Update
    int atualizar(Pedido pedido); // ✅ Retorna o número de linhas atualizadas

    @Query("SELECT * FROM Pedido")
    LiveData<List<Pedido>> listarTodos(); // ✅ Atualiza automaticamente ao mudar os dados

    @Query("SELECT * FROM Pedido WHERE id = :id LIMIT 1")
    LiveData<Pedido> buscarPorId(int id); // ✅ Para evitar erro de threading
}
