package projetofinal.dao;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;
import projetofinal.models.Cliente;
import java.util.List;

@Dao
public interface ClienteDao {

    // 🔹 Insere um cliente (substitui se já existir)
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long inserir(Cliente cliente);

    // 🔹 Excluir um cliente
    @Delete
    void excluir(Cliente cliente);

    // 🔹 Excluir cliente pelo ID
    @Query("DELETE FROM Cliente WHERE id = :id")
    void excluirPorId(int id);

    // 🔹 Atualizar um cliente
    @Update
    void atualizar(Cliente cliente);

    // 🔹 Buscar todos os clientes
    @Query("SELECT * FROM Cliente ORDER BY nome ASC")
    List<Cliente> listarTodos();

    // 🔹 Buscar cliente pelo ID
    @Query("SELECT * FROM Cliente WHERE id = :id LIMIT 1")
    Cliente buscarPorId(int id);

    // 🔹 Buscar clientes por nome (permite nomes semelhantes)
    @Query("SELECT * FROM Cliente WHERE nome LIKE '%' || :nome || '%'")
    List<Cliente> buscarPorNome(String nome);

    // 🔹 Buscar cliente pelo contato
    @Query("SELECT * FROM Cliente WHERE contato = :contato LIMIT 1")
    Cliente buscarPorContato(String contato);

    // 🔹 Verificar se um cliente existe pelo ID
    @Query("SELECT COUNT(*) FROM Cliente WHERE id = :id")
    int clienteExiste(int id);

    // 🔹 Excluir todos os clientes (útil para testes)
    @Query("DELETE FROM Cliente")
    void excluirTodos();
}
