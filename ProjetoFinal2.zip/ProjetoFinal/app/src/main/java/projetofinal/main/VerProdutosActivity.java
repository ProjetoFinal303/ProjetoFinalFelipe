package projetofinal.main;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.example.projetofinal.R;

public class VerProdutosActivity extends AppCompatActivity {
    private TextView txtProdutos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ver_produtos);

        txtProdutos = findViewById(R.id.txtProdutos);
        txtProdutos.setText(
                "🍔 Hambúrguer\n" +
                        "🍟 Batata Frita\n" +
                        "🥤 Refrigerante\n" +
                        "🍦 Milkshake\n" +
                        "🍗 Coxinha\n" +
                        "🥟 Pastel\n" +
                        "🥖 Joelho\n" +
                        "🍹 Caldo de Cana\n" +
                        "🥤 Guaracamp"
        );
    }
}
