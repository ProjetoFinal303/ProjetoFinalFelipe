package projetofinal.main;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.os.AsyncTask;

import projetofinal.database.AppDatabase;
import projetofinal.dao.ClienteDao;
import projetofinal.models.Cliente;
import com.example.projetofinal.R;

public class ExcluirClienteActivity extends AppCompatActivity {
    private EditText edtId;
    private ClienteDao clienteDao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_excluir_cliente);

        edtId = findViewById(R.id.edtId);
        Button btnExcluir = findViewById(R.id.btnExcluir);

        clienteDao = AppDatabase.getInstance(this).clienteDao();

        btnExcluir.setOnClickListener(v -> {
            String idTexto = edtId.getText().toString().trim();
            if (idTexto.isEmpty()) {
                Toast.makeText(this, "Informe um ID válido!", Toast.LENGTH_SHORT).show();
                return;
            }

            int id = Integer.parseInt(idTexto);

            AsyncTask.execute(() -> {
                Cliente cliente = clienteDao.buscarPorId(id);
                if (cliente != null) {
                    clienteDao.excluir(cliente);
                    runOnUiThread(() -> Toast.makeText(this, "Cliente excluído!", Toast.LENGTH_SHORT).show());
                    finish();
                } else {
                    runOnUiThread(() -> Toast.makeText(this, "Cliente não encontrado!", Toast.LENGTH_SHORT).show());
                }
            });
        });
    }
}
