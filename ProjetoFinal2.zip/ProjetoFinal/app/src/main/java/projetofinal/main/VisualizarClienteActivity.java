package projetofinal.main;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.example.projetofinal.R;

import projetofinal.database.AppDatabase;
import projetofinal.dao.ClienteDao;
import projetofinal.models.Cliente;

public class VisualizarClienteActivity extends AppCompatActivity {
    private EditText edtIdCliente;
    private Button btnBuscarCliente, btnVoltar;
    private TextView txtDadosCliente;
    private ClienteDao clienteDao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visualizar_cliente);

        // Inicializando os elementos da interface
        edtIdCliente = findViewById(R.id.edtIdCliente);
        btnBuscarCliente = findViewById(R.id.btnBuscarCliente);
        btnVoltar = findViewById(R.id.btnVoltar);
        txtDadosCliente = findViewById(R.id.txtDadosCliente);

        // Inicializando o banco de dados
        AppDatabase db = AppDatabase.getInstance(this);
        clienteDao = db.clienteDao();

        // Evento de clique para buscar cliente
        btnBuscarCliente.setOnClickListener(v -> buscarCliente());

        // Evento de clique para voltar à tela inicial
        btnVoltar.setOnClickListener(v -> {
            finish(); // Apenas fecha a tela atual e retorna à anterior
        });
    }

    private void buscarCliente() {
        String idTexto = edtIdCliente.getText().toString().trim();

        if (idTexto.isEmpty()) {
            Toast.makeText(this, "Digite um ID válido", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            int idCliente = Integer.parseInt(idTexto);
            Cliente cliente = clienteDao.buscarPorId(idCliente);  // ✅ Método corrigido

            if (cliente != null) {
                // Exibir os dados do cliente formatados
                String dados = "ID: " + cliente.getId() + "\n" +
                        "Nome: " + cliente.getNome() + "\n" +
                        "Contato: " + cliente.getContato();
                txtDadosCliente.setText(dados);
            } else {
                txtDadosCliente.setText("Cliente não encontrado.");
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "ID inválido. Digite um número.", Toast.LENGTH_SHORT).show();
        }
    }
}
