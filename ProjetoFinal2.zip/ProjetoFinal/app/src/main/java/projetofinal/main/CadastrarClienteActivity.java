package projetofinal.main;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.example.projetofinal.R;

import projetofinal.database.AppDatabase;
import projetofinal.dao.ClienteDao;
import projetofinal.models.Cliente;
import java.util.concurrent.Executors;

public class CadastrarClienteActivity extends AppCompatActivity {

    private EditText edtNome, edtContato;
    private Button btnCadastrar, btnSalvar;
    private ClienteDao clienteDao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastrar_cliente);

        // Inicializa os componentes
        edtNome = findViewById(R.id.edtNome);
        edtContato = findViewById(R.id.edtContato);
        btnCadastrar = findViewById(R.id.btnCadastrar);
        btnSalvar = findViewById(R.id.btnSalvar);

        // Inicializa o banco de dados
        clienteDao = AppDatabase.getInstance(this).clienteDao();

        // Botão Cadastrar (apenas exibe um aviso, sem alterar os campos)
        btnCadastrar.setOnClickListener(view ->
                Toast.makeText(this, "Preencha os campos e clique em Salvar", Toast.LENGTH_SHORT).show()
        );

        // Botão Salvar (grava os dados e volta para a tela inicial)
        btnSalvar.setOnClickListener(view -> {
            String nome = edtNome.getText().toString().trim();
            String contato = edtContato.getText().toString().trim();

            if (nome.isEmpty() || contato.isEmpty()) {
                Toast.makeText(this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show();
                return;
            }

            Cliente cliente = new Cliente(nome, contato);

            Executors.newSingleThreadExecutor().execute(() -> {
                clienteDao.inserir(cliente);

                runOnUiThread(() -> {
                    Toast.makeText(this, "Cliente cadastrado com sucesso!", Toast.LENGTH_SHORT).show();
                    finish(); // Volta para a tela anterior
                });
            });
        });
    }
}
